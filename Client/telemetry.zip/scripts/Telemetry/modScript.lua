load("Telemetry")
setExtensionUnloadMode("Telemetry", "manual")
