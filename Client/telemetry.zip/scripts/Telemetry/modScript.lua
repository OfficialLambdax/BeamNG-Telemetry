load("Telemetry")
setExtensionUnloadMode("Telemetry", "manual")

extensions.core_input_categories.telemetry_mod = {
	order = 0,
	icon = "extension",
	title = "Telemetry",
	desc = "Telemetry Controls"
}